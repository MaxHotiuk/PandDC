﻿namespace LabWork1MatrixSumSub;
using LabWork1MatrixSumSub.Menu;
public static class Program
{
    public static void Main()
    {
        Menu.Menu menu = new();
        menu.Start();
    }
}