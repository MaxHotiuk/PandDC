﻿namespace LabWork2MatrixMult;
using LabWork2MatrixMult.Menu;
public static class Program
{
    public static void Main()
    {
        Menu.Menu menu = new();
        menu.Start();
    }
}